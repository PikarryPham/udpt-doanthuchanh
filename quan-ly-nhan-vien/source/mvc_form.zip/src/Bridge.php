<?php
    require_once "./src/core/ConnectDB.php";
    require_once "./src/core/App.php";
    require_once "./src/core/Controllers.php";
?>