<form method="post" action="./check" >
    <input type="text" name="demo">
</form>