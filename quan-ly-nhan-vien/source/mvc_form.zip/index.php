<?php
    session_start();
    require_once "./src/Bridge.php";
    $app = new App();
?>